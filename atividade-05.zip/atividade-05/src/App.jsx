import './App.css'
import frontend from './assets/img/frontend.jfif';
import responsive from './assets/img/responsive.jpg';
import performance from './assets/img/performance.jfif';
import acessibility from './assets/img/acessibility.jfif';

function App() {
  return (
    <>
      <header>
        <h1>Minha Página Exemplo</h1>
        <ul>
          <li id="inicio"><a href="#">Início</a></li>
          <li id="sobre"><a href="#">Sobre</a></li>
          <li id="contato"><a href="#">Contato</a></li>
        </ul>
      </header>
      <topper>
        <h1>Bem-vindo ao Futuro do Desenvolvimento Web</h1>
        <p>Criando experiências digitais excepcionais com tecnologia moderna e design responsivo.</p>
      </topper>
      <div class="phrase">
        <p><i>O sucesso é a soma de pequenos esforços repetidos dia após dia.</i></p>
        <p class="name">— Robert Collier</p>
      </div>
      <section class="cards">
      <div class="card">
        <img src={frontend} alt="" />
        <h3>Desenvolvimento FrontEnd</h3>
        <p>Criação de interfaces modernas e responsivas utilizando as mais recentes tecnologias web.</p>
      </div>
      <div class="card">
        <img src={responsive} alt="" />
        <h3>Design Responsivo</h3>
        <p>Layouts que se adaptam perfeitamente a qualquer dispositivo, desde smartphones até desktops.</p>
      </div>
      <div class="card">
        <img src={performance} alt="" />
        <h3>Performance e SEO</h3>
        <p>Otimização avançada para garantir carregamento rápido e melhor posicionamento nos buscadores.</p>
      </div>
      <div class="card">
        <img src={acessibility} alt="" />
        <h3>Acessibilidade Web</h3>
        <p>Desenvolvimento inclusivo seguindo as diretrizes WCAG para atender todos os usuários.</p>
      </div>
      </section>
      <div class="bluebox">
        <h1>Transforme Sua Presença Digital</h1>
        <p>Junte-se a centenas de empresas que já transformaram seus negócios com nossas soluções web inovadoras e estratégias digitais eficazes.</p>
      </div>
      <footer>
          <ul>
          <li id="privatepolicy"><a href="#">Política de Privacidade</a></li>
          <li id="terms"><a href="#">Termos de Uso</a></li>
          <li id="cookies"><a href="#">Cookies</a></li>
          <li id="support"><a href="#">Suporte</a></li>
        </ul>
        <p>© 2025 Minha Página Exemplo. Todos os direitos reservados.</p>
      </footer>
    </>
  )
}

export default App
